from __future__ import annotations

import threading
from typing import TYPE_CHECKING

import flet as ft

from .models import MarketplaceItem
from .theme import (
    AUREX_BG,
    AUREX_CARD,
    AUREX_GOLD,
    AUREX_GOLD_SOFT,
    AUREX_MUTED,
    AUREX_SLATE,
    AUREX_TEXT,
)

if TYPE_CHECKING:
    from .app import AurexFletApp


_IMAGE_HEIGHT = 190


def build_marketplace_view(app: "AurexFletApp") -> ft.View:
    page = app.page

    if not app.session.market_items and not app.market_loading and not app._market_bootstrap_requested:
        app.market_loading = True
        app._market_bootstrap_requested = True
        threading.Thread(
            target=app._load_marketplace_worker,
            args=(True,),
            daemon=True,
        ).start()

    def build_image(item: MarketplaceItem) -> ft.Control:
        cached = app.session.image_cache.get(item.image_url)
        if cached is None and item.image_url:
            app.prefetch_image_async(item.image_url)
        if cached:
            return ft.Image(
                src_base64=cached,
                height=_IMAGE_HEIGHT,
                fit=ft.ImageFit.COVER,
                border_radius=ft.border_radius.only(top_left=20, top_right=20),
            )
        if cached == "":
            return ft.Container(
                height=_IMAGE_HEIGHT,
                bgcolor="#0F1115",
                alignment=ft.alignment.center,
                border_radius=ft.border_radius.only(top_left=20, top_right=20),
                content=ft.Icon(ft.Icons.BROKEN_IMAGE_OUTLINED, color=AUREX_MUTED),
            )
        return ft.Shimmer(
            base_color="#1F232B",
            highlight_color="#2C313B",
            content=ft.Container(
                height=_IMAGE_HEIGHT,
                bgcolor="#1F232B",
                border_radius=ft.border_radius.only(top_left=20, top_right=20),
            ),
        )

    def build_item_card(item: MarketplaceItem) -> ft.Control:
        image_control = build_image(item)
        card = ft.Card(
            bgcolor=AUREX_CARD,
            elevation=2,
            shape=ft.RoundedRectangleBorder(radius=20),
            content=ft.Column(
                spacing=0,
                controls=[
                    image_control,
                    ft.Container(
                        padding=16,
                        content=ft.Column(
                            spacing=6,
                            controls=[
                                ft.Text(
                                    item.title,
                                    size=16,
                                    weight=ft.FontWeight.BOLD,
                                    max_lines=2,
                                    color=AUREX_TEXT,
                                ),
                                ft.Text(
                                    item.description,
                                    size=12,
                                    color=AUREX_MUTED,
                                    max_lines=2,
                                    overflow=ft.TextOverflow.ELLIPSIS,
                                ),
                                ft.Row(
                                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                                    controls=[
                                        ft.Text(
                                            f"${item.price:.2f}",
                                            color=AUREX_GOLD_SOFT,
                                            weight=ft.FontWeight.BOLD,
                                        ),
                                        ft.Container(
                                            padding=ft.padding.symmetric(horizontal=10, vertical=4),
                                            bgcolor="#21252D",
                                            border_radius=999,
                                            content=ft.Text("View", size=11, color=AUREX_TEXT),
                                        ),
                                    ],
                                ),
                                ft.Text(f"by {item.author}", size=11, color=AUREX_MUTED),
                            ],
                        ),
                    ),
                ],
            ),
        )
        return ft.Container(
            col={
                ft.ResponsiveRowBreakpoint.XS: 12,
                ft.ResponsiveRowBreakpoint.MD: 6,
                ft.ResponsiveRowBreakpoint.LG: 4,
                ft.ResponsiveRowBreakpoint.XL: 3,
            },
            content=card,
        )

    if app.market_error and not app.session.market_items:
        item_controls = [
            ft.Container(
                padding=24,
                border_radius=18,
                bgcolor=AUREX_CARD,
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Icon(ft.Icons.ERROR_OUTLINE, size=48, color="#EF4444"),
                        ft.Text(app.market_error, text_align=ft.TextAlign.CENTER),
                        ft.FilledButton(
                            text="Retry",
                            on_click=lambda _: app.load_marketplace_async(reset=True),
                        ),
                    ],
                ),
            )
        ]
    elif not app.session.market_items and app.market_loading:
        item_controls = [
            ft.Container(
                padding=24,
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.ProgressRing(),
                        ft.Text("Loading marketplace items..."),
                    ],
                ),
            )
        ]
    elif not app.session.market_items:
        item_controls = [
            ft.Container(
                padding=24,
                border_radius=18,
                bgcolor=AUREX_CARD,
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Icon(ft.Icons.INVENTORY_2_OUTLINED, size=48, color=AUREX_MUTED),
                        ft.Text("No assets available"),
                        ft.FilledButton(
                            text="Refresh",
                            on_click=lambda _: app.load_marketplace_async(reset=True),
                        ),
                    ],
                ),
            )
        ]
    else:
        item_controls = [build_item_card(item) for item in app.session.market_items]

    username = app.session.user_data.username if app.session.user_data else "Guest"

    return ft.View(
        route="/marketplace",
        bgcolor=AUREX_BG,
        controls=[
            ft.Container(
                expand=True,
                padding=24,
                content=ft.Column(
                    expand=True,
                    spacing=18,
                    controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                            controls=[
                                ft.Column(
                                    spacing=4,
                                    controls=[
                                        ft.Text("Aurex Marketplace", size=28, weight=ft.FontWeight.BOLD),
                                        ft.Text(f"Welcome, {username}", color=AUREX_MUTED),
                                    ],
                                ),
                                ft.Row(
                                    spacing=10,
                                    controls=[
                                        ft.OutlinedButton(
                                            text="Refresh",
                                            icon=ft.Icons.REFRESH,
                                            on_click=lambda _: app.load_marketplace_async(reset=True),
                                        ),
                                        ft.FilledButton(
                                            text="Upload",
                                            icon=ft.Icons.CLOUD_UPLOAD,
                                            bgcolor=AUREX_GOLD,
                                            color="#1A1A1B",
                                            on_click=lambda _: page.go("/upload"),
                                        ),
                                        ft.IconButton(
                                            icon=ft.Icons.SETTINGS,
                                            on_click=lambda _: page.go("/settings"),
                                        ),
                                        ft.FilledButton(
                                            text="Logout",
                                            icon=ft.Icons.LOGOUT,
                                            on_click=lambda _: app.logout(),
                                        ),
                                    ],
                                ),
                            ],
                        ),
                        ft.Container(
                            padding=16,
                            border_radius=18,
                            bgcolor=AUREX_CARD,
                            border=ft.border.all(1, AUREX_SLATE),
                            content=ft.Row(
                                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                                controls=[
                                    ft.Text(
                                        "Discover newly uploaded blockchain-backed assets.",
                                        color=AUREX_MUTED,
                                    ),
                                    ft.Row(
                                        controls=[
                                            ft.Text(
                                                "Loading..." if app.market_loading else f"{len(app.session.market_items)} items",
                                                color=AUREX_GOLD_SOFT,
                                            ),
                                            ft.ProgressRing(width=16, height=16, stroke_width=2, visible=app.market_loading),
                                        ],
                                    ),
                                ],
                            ),
                        ),
                        ft.ResponsiveRow(
                            columns=12,
                            spacing=16,
                            run_spacing=16,
                            controls=item_controls,
                        ),
                    ],
                ),
            )
        ],
    )
