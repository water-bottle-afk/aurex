"""
Aurex Blockchain Server - Handles client connections and marketplace (ORM: DB/marketplace.db)
One persistent connection per client, event-based processing

PROTOCOL SPECIFICATION
======================
All client-server communication uses TLS on port 23456 with 2-byte length prefix.

Message Format: [2-byte length][protocol command]

Supported Commands:
  1. START - Connection initialization
     Send: START|Client_Flutter_App
     Recv: ACCPT|Connection accepted
  
  2. LOGIN - User authentication (by USERNAME)
     Send: LOGIN|username|password
     Recv: OK|username or ERR|error_message
  
  3. SIGNUP - User registration (by USERNAME)
     Send: SIGNUP|username|password
     Recv: OK or ERR|error_message
  
  4. SEND_CODE - Request password reset OTP code via username
     Send: SEND_CODE|username
     Recv: OK|code_sent or ERR|error_message
  
  5. VERIFY_CODE - Verify OTP code for password reset
     Send: VERIFY_CODE|username|otp_code
     Recv: OK|token or ERR|error_message
  
  6. UPDATE_PASSWORD - Change user password (after OTP verification)
     Send: UPDATE_PASSWORD|username|new_password
     Recv: OK or ERR|error_message
  
  7. LOGOUT - User logout
     Send: LOGOUT|username
     Recv: OK or ERR|error_message
  
  8. UPLOAD_INIT - Start chunked upload session
     Send: UPLOAD_INIT|base64(json) (includes asset_hash + mint signature)
     Recv: OK|upload_id|chunk_size or ERR|error_message

  9. UPLOAD_CHUNK - Send file chunk (base64)
     Send: UPLOAD_CHUNK|upload_id|seq|total|base64(chunk)
     Recv: OK|seq or ERR|error_message

  10. UPLOAD_FINISH - Finalize upload (Drive + DB)
      Send: UPLOAD_FINISH|upload_id
      Recv: OK|asset_name|drive_url or ERR|error_message

  11. UPLOAD_ABORT - Cancel an in-progress upload
      Send: UPLOAD_ABORT|upload_id
      Recv: OK|message or ERR|error_message

  12. UPLOAD - Legacy direct-URL upload/register (disabled)
      Send: UPLOAD|asset_name|username|google_drive_url|file_type|cost
      Recv: ERR|Legacy upload disabled
  
  13. GET_ITEMS - Get all marketplace items
     Send: GET_ITEMS
     Recv: OK|item1|item2|... or ERR|error_message
  
  14. GET_ITEMS_PAGINATED - Lazy scrolling with timestamp cursor
      Send: GET_ITEMS_PAGINATED|limit[|timestamp]
      Recv: OK|item1|item2|... or ERR|error_message
  
  15. BUY - Purchase an asset from marketplace
      Send: BUY|asset_id|username|amount|tx_id|timestamp|public_key|signature
      Recv: OK|PENDING|transaction_id or ERR|error_message
  
  16. SEND - Send purchased asset to another user
      Send: SEND|asset_id|sender_username|receiver_username|tx_id|timestamp|public_key|signature
      Recv: OK|transaction_id or ERR|error_message
  
  17. GET_PROFILE - Get user profile (anonymous - username only)
      Send: GET_PROFILE|username
      Recv: OK|username|email|created_at or ERR|error_message

  18. GET_USER_BY_EMAIL - Look up username by email (e.g. for Google sign-in)
      Send: GET_USER_BY_EMAIL|email
      Recv: OK|username or ERR|error_message

  19. GET_TX_STATUS - Check blockchain purchase status
      Send: GET_TX_STATUS|tx_id
      Recv: OK|STATUS|message or ERR|error_message

  20. GET_ITEMS_BY_USER - Get assets owned by a user
      Send: GET_ITEMS_BY_USER|username
      Recv: OK|items_json or ERR|error_message

  21. GET_WALLET - Get wallet balance for a user
      Send: GET_WALLET|username
      Recv: OK|balance|updated_at or ERR|error_message

  22. GET_NOTIFICATIONS - Get notifications for a user
      Send: GET_NOTIFICATIONS|username|limit
      Recv: OK|json_list|unread_count or ERR|error_message

  23. MARK_NOTIFICATIONS_READ - Mark all notifications as read
      Send: MARK_NOTIFICATIONS_READ|username
      Recv: OK|read or ERR|error_message

  24. REGISTER_DEVICE - Register push notification token
      Send: REGISTER_DEVICE|username|platform|token
      Recv: OK|registered or ERR|error_message

  25. LIST_ITEM - List an owned asset for sale
      Send: LIST_ITEM|asset_id|username|price
      Recv: OK|LISTED or ERR|error_message

  26. UNLIST_ITEM - Remove an asset from the marketplace
      Send: UNLIST_ITEM|asset_id|username
      Recv: OK|UNLISTED or ERR|error_message
"""

import base64
import datetime
import json
import hashlib
import logging
import os
import queue
import random
import re
import socket
import ssl as ssl_module
import struct
import threading
import time
import shutil
import uuid
import urllib.error
import urllib.request
from importlib import util as importlib_util
from dataclasses import dataclass, field
from pathlib import Path
from config import (
    SERVER_HOST, SERVER_PORT, SERVER_IP,
    BROADCAST_PORT, SSL_CERT_FILE, SSL_KEY_FILE,
    LOGGING_LEVEL, BLOCK_CONFIRMATION_PORT,
    GATEWAY_HOST, GATEWAY_PORT,
    UPLOADS_DIR,
    UPLOAD_TMP_DIR, UPLOAD_CHUNK_SIZE,
    TX_TIME_WINDOW_SECONDS,
    FCM_ENABLED, FCM_SERVER_KEY,
)
from classes import PROTO, CustomLogger
from DB_ORM import MarketplaceDB
from cryptography.hazmat.primitives.asymmetric import ed25519

_UPLOADS_DIR_PATH = (Path(__file__).parent / UPLOADS_DIR).resolve()
_UPLOADS_DIR_PATH.mkdir(parents=True, exist_ok=True)

server_logger = CustomLogger("server", LOGGING_LEVEL).logger


def _read_image_bytes(filename: str, max_width: int = 400) -> bytes | None:
    path = _resolve_upload_file(filename)
    if path is None:
        return None
    try:
        return path.read_bytes()
    except Exception:
        return None


def _resolve_upload_file(filename: str) -> Path | None:
    rel_name = (filename or "").strip().replace("\\", "/")
    if not rel_name:
        return None
    rel_path = Path(rel_name)
    if rel_path.is_absolute() or any(part in ("", ".", "..") for part in rel_path.parts):
        return None
    try:
        resolved = (_UPLOADS_DIR_PATH / rel_path).resolve()
        resolved.relative_to(_UPLOADS_DIR_PATH)
    except Exception:
        return None
    return resolved


def _safe_asset_filename(name: str, extension: str, fallback: str = "asset") -> str:
    raw_name = Path(name or "").stem if name else ""
    safe_stem = re.sub(r"[^A-Za-z0-9._-]+", "_", raw_name).strip("._")
    if not safe_stem:
        safe_stem = fallback
    normalized_ext = (extension or "").strip().lower().lstrip(".")
    return f"{safe_stem}.{normalized_ext}" if normalized_ext else safe_stem


def _canonical_tx_message(sender, data):
    payload = {"sender": sender, "data": data}
    return json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()


def _verify_ed25519_signature(public_key_b64, message_bytes, signature_b64):
    try:
        public_key_raw = base64.b64decode(public_key_b64.encode())
        signature_raw = base64.b64decode(signature_b64.encode())
        public_key = ed25519.Ed25519PublicKey.from_public_bytes(public_key_raw)
        public_key.verify(signature_raw, message_bytes)
        return True
    except Exception:
        return False


def _is_timestamp_valid(ts_str):
    if not ts_str:
        return False
    try:
        ts_str = ts_str.replace('Z', '+00:00')
        ts = datetime.datetime.fromisoformat(ts_str)
        now = datetime.datetime.now(datetime.UTC).replace(tzinfo=None)
        delta = abs((now - ts.replace(tzinfo=None)).total_seconds())
        return delta <= TX_TIME_WINDOW_SECONDS
    except Exception:
        return False


def _sha256_file(path):
    hasher = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def _resolve_path(path_value: str) -> str:
    path_obj = Path(path_value)
    if not path_obj.is_absolute():
        path_obj = (Path(__file__).parent / path_obj).resolve()
    return str(path_obj)


def _detect_local_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("8.8.8.8", 80))
            local_ip = sock.getsockname()[0]
            if local_ip:
                return local_ip
    except Exception:
        pass
    return "127.0.0.1"


def _resolve_server_ip(config_ip: str, bind_host: str) -> str:
    candidate = (config_ip or "").strip()
    if candidate and candidate not in ("0.0.0.0", "127.0.0.1", "localhost"):
        return candidate
    if bind_host and bind_host not in ("0.0.0.0", "127.0.0.1", "localhost"):
        return bind_host
    return _detect_local_ip()


def _load_blockchain_notifications_manager():
    classes_path = (Path(__file__).parent.parent / "blockchain" / "classes.py").resolve()
    spec = importlib_util.spec_from_file_location("blockchain_classes", classes_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load blockchain classes from {classes_path}")
    module = importlib_util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.NotificationsManager


NotificationsManager = _load_blockchain_notifications_manager()


@dataclass
class UploadSession:
    """Track a chunked upload session per client."""
    upload_id: str
    username: str
    asset_name: str
    description: str
    file_type: str
    cost: float
    file_size: int
    original_name: str
    temp_path: str
    asset_hash: str = ''
    mint_tx_id: str = ''
    mint_timestamp: str = ''
    public_key: str = ''
    mint_signature: str = ''
    total_chunks: int = 0
    received_chunks: int = 0
    next_seq: int = 0
    bytes_received: int = 0
    created_at: float = field(default_factory=time.time)


class ClientSession:
    """Represents one authenticated client connection"""
    def __init__(self, sock, addr, logging_level, server):
        self.socket = sock
        self.address = addr
        self.server = server
        
        # Pass socket directly to PROTO constructor instead of assigning afterward
        self.proto = PROTO("ClientSession", logging_level=logging_level, cln_sock=sock)
        
        self.logger = CustomLogger(f"Session-{addr[0]}:{addr[1]}", logging_level)
        self.Print = self.logger.Print
        
        self.username = None
        self.server.unregister_session(self)
        self.is_authenticated = False
        self.is_connected = True
        self.db = MarketplaceDB()  # ORM: DB/marketplace.db (users + marketplace_items)
        self.notifications_manager = server.notifications_manager
        self.create_and_push_notification = server.create_and_push_notification

        # Ensure upload temp directory exists
        self.upload_tmp_dir = Path(UPLOAD_TMP_DIR)
        if not self.upload_tmp_dir.is_absolute():
            self.upload_tmp_dir = (Path(__file__).parent / self.upload_tmp_dir).resolve()
        self.upload_tmp_dir.mkdir(parents=True, exist_ok=True)

        self.handlers = {
            "START": self.handle_start,
            "LOGIN": self.handle_login,
            "LOGIN_GOOGLE": self.handle_login_google,
            "SIGNUP": self.handle_signup,
            "GET_USER_BY_EMAIL": self.handle_get_user_by_email,
            "SEND_CODE": self.handle_send_code,
            "VERIFY_CODE": self.handle_verify_code,
            "UPDATE_PASSWORD": self.handle_update_password,
            "LOGOUT": self.handle_logout,
            "UPLOAD": self.handle_log_asset,
            "UPLOAD_INIT": self.handle_upload_init,
            "UPLOAD_FINISH": self.handle_upload_finish,
            "UPLOAD_ABORT": self.handle_upload_abort,
            "GET_ASSET_BINARY": self.handle_get_asset_binary,
            "GET_ITEMS": self.handle_asset_list,
            "GET_ITEMS_PAGINATED": self.handle_get_items_paginated,
            "BUY": self.handle_buy_asset,
            "SEND": self.handle_send_asset,
            "GET_PROFILE": self.handle_get_profile,
            "GET_TX_STATUS": self.handle_get_tx_status,
            "GET_ITEMS_BY_USER": self.handle_get_items_by_user,
            "GET_WALLET": self.handle_get_wallet,
            "GET_NOTIFICATIONS": self.handle_get_notifications,
            "MARK_NOTIFICATIONS_READ": self.handle_mark_notifications_read,
            "REGISTER_DEVICE": self.handle_register_device,
            "LIST_ITEM": self.handle_list_item,
            "UNLIST_ITEM": self.handle_unlist_item,
        }
    
    def process_message(self, message):
        """Parse and handle incoming message"""
        try:
            parts = message.split('|')
            command = parts[0].strip()
            tail = parts[1:]
            
            if command not in self.handlers:
                self.Print(f" Unknown command: {command}", 40)
                self.Print(f"   Available commands: {', '.join(self.handlers.keys())}", 30)
                return f"ERR02|Unknown command: {command}"
            
            handler = self.handlers[command]
            self.Print(f" Processing command: {command}", 10)
            return handler(tail)
        except Exception as e:
            self.Print(f" Error processing message: {e}", 40)
            return f"ERR99|{str(e)}"
    
    def handle_start(self, params):
        """Protocol Message 1: START - Initialize connection"""
        self.Print(" START message received - accepting connection", 20)
        return "ACCPT|Connection accepted"
    
    def handle_login(self, params):
        """Protocol Message: LOGIN - Username/Password authentication
        Format: LOGIN|username|password
        Returns: OK|username or ERR|error_message
        """
        if len(params) < 2:
            self.Print(" Invalid login format", 40)
            return "ERR01|Invalid login format"
        
        username = params[0].strip()
        password = params[1].strip()
        
        # Validate username format
        if not username or '|' in username or ' ' in username:
            self.Print(f" Invalid username format: {username}", 40)
            return "ERR01|Invalid username format"
        
        try:
            user_obj = self.db.get_user(username)
            if user_obj and user_obj.verify_password(password):
                self.username = username
                self.is_authenticated = True
                self.server.register_authenticated_session(self)
                self.Print(f" [RECV] LOGIN|{username}|***", 20)
                self.Print(f" User {username} logged in", 20)
                return f"OK|{username}"
            self.Print(f" Invalid credentials for {username}", 40)
            return "ERR01|user not found"
        except Exception as e:
            self.Print(f" Login error: {e}", 40)
            return f"ERR99|{str(e)}"
    
    def handle_signup(self, params):
        """Protocol Message: SIGNUP - User registration
        Format: SIGNUP|username|password
        Returns: OK|username or ERR|error_message
        """
        if len(params) < 2:
            self.Print(" Invalid signup format", 40)
            return "ERR10|Invalid signup format: SIGNUP|username|password|email"
        
        username = params[0].strip()
        password = params[1].strip()
        email = params[2].strip() if len(params) >= 3 else f"{username}@aurex.local"
        
        # Validate fields - no pipes or spaces
        if '|' in username or '|' in password or '|' in email:
            self.Print(f" Invalid characters in signup fields", 40)
            return "ERR10|Fields cannot contain '|'"
        
        if username != params[0] or password != params[1]:
            self.Print(f" Fields have leading/trailing spaces", 40)
            return "ERR10|Fields cannot have leading/trailing spaces"
        
        # Validate inputs
        if not username or not password:
            self.Print(f" Missing required fields for signup", 40)
            return "ERR10|Missing required fields"
        
        # Username validation: 3-20 chars, alphanumeric + underscore
        import re
        if not re.match(r'^[a-zA-Z0-9_]{3,20}$', username):
            self.Print(f" Invalid username format: {username}", 40)
            return "ERR10|Username: 3-20 chars, alphanumeric + underscore only"
        
        # Password validation: min 6 chars
        if len(password) < 6:
            self.Print(f" Password too short", 40)
            return "ERR10|Password must be at least 6 characters"
        
        if not email or ' ' in email or '@' not in email:
            return "ERR10|Invalid email format"
        success, message = self.db.add_user(username, password, email)
        if success:
            self.Print(f" User {username} signed up", 20)
            return f"OK|{username}"
        self.Print(f" Signup failed: {message}", 40)
        return f"ERR10|{message}"

    def handle_login_google(self, params):
        """LOGIN_GOOGLE - Authenticate via Google-verified email (no password required).
        Format: LOGIN_GOOGLE|email
        Returns: OK|username or ERR|error_message
        """
        if len(params) < 1:
            return "ERR01|Invalid format: LOGIN_GOOGLE|email"
        email = params[0].strip()
        if not email or '|' in email or ' ' in email:
            return "ERR01|Invalid email format"
        user_obj = self.db.get_user_by_email(email)
        if not user_obj:
            self.Print(f" LOGIN_GOOGLE: no account for {email}", 40)
            return "ERR02|No account found for this email. Please sign up first."
        self.username = user_obj.username
        self.is_authenticated = True
        self.server.register_authenticated_session(self)
        self.Print(f" LOGIN_GOOGLE: {user_obj.username} authenticated via Google", 20)
        return f"OK|{user_obj.username}"

    def handle_get_user_by_email(self, params):
        """GET_USER_BY_EMAIL - Look up username by email (e.g. for Google sign-in).
        Format: GET_USER_BY_EMAIL|email
        Returns: OK|username or ERR|error_message
        """
        if len(params) < 1:
            return "ERR01|Invalid format: GET_USER_BY_EMAIL|email"
        email = params[0].strip()
        if not email or '|' in email:
            return "ERR01|Invalid email format"
        user_obj = self.db.get_user_by_email(email)
        if user_obj:
            self.Print(f" User by email {email}: {user_obj.username}", 20)
            return f"OK|{user_obj.username}"
        self.Print(f" No user for email {email}", 40)
        return "ERR02|User not found"

    def handle_send_code(self, params):
        """Protocol Message: SEND_CODE - Send OTP code for password reset
        Format: SEND_CODE|email
        Returns: OK|otp_sent or ERR|error_message
        """
        if len(params) < 1:
            self.Print(" Invalid SEND_CODE format", 40)
            return "ERR04|Invalid format: SEND_CODE|email"
        
        email = params[0].strip()
        
        if not email or '|' in email or ' ' in email:
            self.Print(f" Invalid email format", 40)
            return "ERR04|Invalid email format"
        user_obj = self.db.get_user_by_email(email)
        if not user_obj:
            self.Print(f" Email {email} not registered", 40)
            return "ERR04|Email not found in system"
        now = datetime.datetime.now()
        if user_obj.verification_code and user_obj.reset_time:
            try:
                expiry = datetime.datetime.fromisoformat(user_obj.reset_time)
                if now < expiry:
                    self.Print(f" Reusing existing reset code for {email}", 20)
                    return f"OK|otp_sent|{user_obj.verification_code}"
            except Exception:
                pass
        otp = str(random.randint(100000, 999999))
        user_obj.set_verification_code(otp)
        user_obj.set_reset_time((datetime.datetime.now() + datetime.timedelta(minutes=5)).isoformat())
        self.db.update_user(user_obj.username, user_obj)
        self.Print(f" Generated reset code for {email}", 20)
        self.Print(f" [DEV] Reset Code: {otp}", 30)
        return f"OK|otp_sent|{otp}"

    def handle_verify_code(self, params):
        """Protocol Message: VERIFY_CODE - Verify OTP code
        Format: VERIFY_CODE|email|otp_code
        Returns: OK|token or ERR|error_message
        """
        if len(params) < 2:
            self.Print(" Invalid VERIFY_CODE format", 40)
            return "ERR08|Invalid format: VERIFY_CODE|email|otp_code"
        
        email = params[0].strip()
        otp_code = params[1].strip()
        
        if not email or not otp_code or '|' in email or '|' in otp_code:
            self.Print(f" Invalid verify code inputs", 40)
            return "ERR08|Invalid input format"
        user_obj = self.db.get_user_by_email(email)
        if not user_obj:
            self.Print(f" Email {email} not found", 40)
            return "ERR08|Email not found"
        if user_obj.is_code_match_and_available(datetime.datetime.now(), otp_code):
            user_obj.is_verified = True
            self.db.update_user(user_obj.username, user_obj)
            self.Print(f" OTP verified for {email}", 20)
            return f"OK|RESET_{user_obj.username}_{int(time.time())}"
        self.Print(f" Invalid or expired OTP for {email}", 40)
        return "ERR08|Invalid or expired OTP"

    def handle_update_password(self, params):
        """Protocol Message: UPDATE_PASSWORD - Change user password (after OTP verification)
        Format: UPDATE_PASSWORD|email|new_password
        Returns: OK or ERR|error_message
        """
        if len(params) < 2:
            self.Print(" Invalid UPDATE_PASSWORD format", 40)
            return "ERR07|Invalid format: UPDATE_PASSWORD|email|new_password"
        
        email = params[0].strip()
        new_password = params[1].strip()
        
        if not email or not new_password or '|' in email or '|' in new_password:
            self.Print(f" Invalid password update inputs", 40)
            return "ERR07|Invalid input format"
        if len(new_password) < 6:
            self.Print(f" New password too short", 40)
            return "ERR07|Password must be at least 6 characters"
        user_obj = self.db.get_user_by_email(email)
        if not user_obj:
            self.Print(f" Email {email} not found", 40)
            return "ERR07|Email not found"
        user_obj.set_password(new_password)
        self.db.update_user(user_obj.username, user_obj)
        self.Print(f" Password updated for {email}", 20)
        return "OK|Password updated successfully"

    def handle_logout(self, params):
        """Protocol Message 7: LGOUT - Logout
        Format: LGOUT|
        """
        self.is_authenticated = False
        username = self.username
        self.username = None
        self.Print(f" User {username} logged out", 20)
        return "EXTLG|Logout successful"

    def _normalize_file_type(self, file_type: str) -> str:
        """Normalize file type to a supported extension."""
        normalized = (file_type or "").strip().lower()
        if normalized == "jpeg":
            normalized = "jpg"
        if normalized == "image":
            normalized = "jpg"
        return normalized

    def _validate_file_signature(self, file_type: str, first_bytes: bytes) -> bool:
        """Validate PNG/JPG magic bytes."""
        if file_type == "png":
            return first_bytes.startswith(b"\x89PNG\r\n\x1a\n")
        if file_type == "jpg":
            return first_bytes.startswith(b"\xff\xd8\xff")
        return False

    def _cleanup_upload(self, upload_id: str) -> None:
        """Remove temp file and session data for a given upload."""
        with self.server.upload_sessions_lock:
            session = self.server.upload_sessions.pop(upload_id, None)
        if not session:
            return
        try:
            if os.path.exists(session.temp_path):
                os.remove(session.temp_path)
        except Exception:
            pass
    
    def handle_log_asset(self, params):
        """Protocol Message: UPLOAD - Legacy direct-URL upload
        Format: UPLOAD|asset_name|username|google_drive_url|file_type|cost
        """
        return "ERR01|Legacy upload disabled. Use chunked upload (UPLOAD_INIT)."
        if not self.is_authenticated:
            return "ERR03|Not authenticated"
        
        if len(params) < 5:
            self.Print(f"[RECV] UPLOAD - Invalid format, got {len(params)} params", 40)
            return "ERR01|Invalid format: UPLOAD|asset_name|username|url|file_type|cost"
        
        try:
            asset_name = params[0].strip()
            username = params[1].strip()
            url = params[2].strip()
            file_type = params[3].strip()
            cost = float(params[4].strip())
            
            # Ensure authenticated user is uploading for their own account
            if username != self.username:
                return "ERR02|Cannot upload on behalf of another user"
            
            # Validate inputs
            if not asset_name or not username or not url or not file_type or cost < 0:
                return "ERR01|Invalid parameters"
            
            normalized_type = self._normalize_file_type(file_type)
            if normalized_type not in ['jpg', 'png']:
                return "ERR01|Invalid file type. Supported: jpg, png"
            
            # Add to marketplace database (ORM: DB/marketplace.db)
            marketplace_db = MarketplaceDB()
            success, message, item_id = marketplace_db.add_marketplace_item(
                asset_name,
                username,
                url,
                normalized_type,
                cost,
            )
            
            if success:
                self.Print(f" Asset uploaded: {asset_name} by {username} - \\${cost}", 20)
                self.create_and_push_notification(
                    username=username,
                    title="Asset uploaded",
                    body=f"Your asset {asset_name} is now in the marketplace.",
                    notif_type="asset_uploaded",
                    asset_id=str(item_id) if item_id else None,
                )
                return f"OK|Asset '{asset_name}' uploaded successfully"
            else:
                self.Print(f" Failed to upload asset: {message}", 40)
                return f"ERR03|{message}"
                
        except ValueError as ve:
            return "ERR01|Invalid cost format"
        except Exception as e:
            self.Print(f" Error processing UPLOAD: {e}", 40)
            return f"ERR99|{str(e)}"

    def handle_upload_init(self, params):
        """
        Protocol: UPLOAD_INIT - Start a chunked upload session.
        Format: UPLOAD_INIT|base64(json)
        Response: OK|upload_id|chunk_size or ERR|message
        """
        if not self.is_authenticated:
            return "ERR02|Not authenticated"
        if len(params) < 1:
            return "ERR01|Invalid format: UPLOAD_INIT|base64(json)"
        try:
            payload = base64.b64decode(params[0].encode("utf-8"))
            data = json.loads(payload.decode("utf-8"))
        except Exception:
            return "ERR01|Invalid init payload"

        asset_name = str(data.get("asset_name", "")).strip()
        username = str(data.get("username", "")).strip()
        description = str(data.get("description", "")).strip()
        file_type = self._normalize_file_type(data.get("file_type", ""))
        original_name = str(data.get("original_name", "")).strip()
        file_size = int(data.get("file_size", 0) or 0)
        asset_hash = str(data.get("asset_hash", "")).strip()
        mint_tx_id = str(data.get("mint_tx_id", "")).strip()
        mint_timestamp = str(data.get("mint_timestamp", "")).strip()
        public_key = str(data.get("public_key", "")).strip()
        mint_signature = str(data.get("mint_signature", "")).strip()
        try:
            cost = float(data.get("cost", 0))
        except Exception:
            cost = -1

        if username != self.username:
            return "ERR02|Unauthorized"
        if not asset_name or not username or cost <= 0 or file_size <= 0:
            return "ERR01|Invalid parameters"
        if file_type not in ("jpg", "png"):
            return "ERR01|Invalid file type. Supported: jpg, png"
        if not asset_hash or not mint_tx_id or not mint_timestamp or not public_key or not mint_signature:
            return "ERR01|Missing mint signature data"
        if not _is_timestamp_valid(mint_timestamp):
            return "ERR01|Invalid mint timestamp"
        with self.server.tx_status_lock:
            if mint_tx_id in self.server.tx_status:
                return "ERR02|Duplicate mint tx_id"
        mint_payload = {
            "action": "asset_mint",
            "tx_id": mint_tx_id,
            "asset_hash": asset_hash,
            "asset_name": asset_name,
            "owner": username,
            "owner_pub": public_key,
            "timestamp": mint_timestamp,
        }
        if not _verify_ed25519_signature(
            public_key,
            _canonical_tx_message(username, mint_payload),
            mint_signature,
        ):
            return "ERR02|Invalid mint signature"
        if not self.db.set_user_public_key(username, public_key, force_update=True):
            return "ERR02|Failed to store public key"

        upload_id = uuid.uuid4().hex
        temp_path = str(self.upload_tmp_dir / f"upload_{upload_id}.bin")
        try:
            self.upload_tmp_dir.mkdir(parents=True, exist_ok=True)
            with open(temp_path, "wb"):
                pass
        except OSError as e:
            return f"ERR99|Cannot create upload temp file: {e}"

        session = UploadSession(
            upload_id=upload_id,
            username=username,
            asset_name=asset_name,
            description=description,
            file_type=file_type,
            cost=cost,
            file_size=file_size,
            original_name=original_name or f"{asset_name}.{file_type}",
            temp_path=temp_path,
            asset_hash=asset_hash,
            mint_tx_id=mint_tx_id,
            mint_timestamp=mint_timestamp,
            public_key=public_key,
            mint_signature=mint_signature,
        )
        with self.server.upload_sessions_lock:
            self.server.upload_sessions[upload_id] = session

        return f"OK|{upload_id}|{UPLOAD_CHUNK_SIZE}"

    def _handle_binary_chunk_inline(self, upload_id: str, seq: int, chunk_bytes: bytes) -> str:
        """
        Internal handler for raw binary upload chunks.
        Called directly from handle_client when a framed message starts with b"UPLOAD_CHUNK|".
        Format (payload bytes): b"UPLOAD_CHUNK|" + upload_id + b"|" + 4-byte-seq-big-endian + raw-data
        """
        if not self.is_authenticated:
            return "ERR02|Not authenticated"
        if not upload_id or upload_id == "[]":
            return "ERR|INVALID_ID"
        with self.server.upload_sessions_lock:
            session = self.server.upload_sessions.get(upload_id)
        if not session:
            self.Print(f" ERR04: upload_id={upload_id!r} not found", 40)
            return "ERR|INVALID_ID"
        if session.username != self.username:
            return "ERR02|Unauthorized"
        if seq != session.next_seq:
            return f"ERR05|Out of order chunk (expected {session.next_seq}, got {seq})"
        if seq == 0 and not self._validate_file_signature(session.file_type, chunk_bytes):
            self._cleanup_upload(upload_id)
            return "ERR06|Invalid file signature"
        session.bytes_received += len(chunk_bytes)
        if session.bytes_received > session.file_size:
            self._cleanup_upload(upload_id)
            return "ERR06|File size exceeded"
        try:
            with open(session.temp_path, "ab") as fh:
                fh.write(chunk_bytes)
                fh.flush()
        except Exception as e:
            self._cleanup_upload(upload_id)
            return f"ERR99|Write failed: {e}"
        session.received_chunks += 1
        session.next_seq += 1
        return f"OK|{seq}"

    def handle_get_asset_binary(self, params):
        """
        GET_ASSET_BINARY - Binary stream download of a stored asset image.
        Format: GET_ASSET_BINARY|username/filename.jpg
        Response: ASSET_START|size (text frame), then one raw binary frame of JPEG bytes.
        Returns None so handle_client skips the default send.
        """
        if not params or not params[0].strip():
            return "ERR01|Invalid format: GET_ASSET|relative/path.jpg"
        rel_path = params[0].strip()
        data = _read_image_bytes(rel_path)
        if data is None:
            return "ERR05|Asset not found or unreadable"
        self.proto.send_one_message(f"ASSET_START|{len(data)}".encode())
        self.proto.send_one_message(data)
        return None  # handle_client must not send an additional response

    def handle_upload_finish(self, params):
        """
        Protocol: UPLOAD_FINISH - Finalize upload, move to user storage, register asset.
        Format: UPLOAD_FINISH|upload_id
        Response: OK|asset_name|relative_path or ERR|message
        """
        if not self.is_authenticated:
            return "ERR02|Not authenticated"
        if len(params) < 1:
            return "ERR01|Invalid format: UPLOAD_FINISH|upload_id"

        upload_id = params[0].strip()
        with self.server.upload_sessions_lock:
            session = self.server.upload_sessions.get(upload_id)
        if not session:
            return "ERR04|Upload session not found"
        if session.username != self.username:
            return "ERR02|Unauthorized"

        try:
            actual_size = os.path.getsize(session.temp_path)
        except OSError:
            actual_size = 0
        if actual_size != session.file_size:
            self._cleanup_upload(upload_id)
            return "ERR06|File size mismatch"
        if session.bytes_received != session.file_size:
            self._cleanup_upload(upload_id)
            return "ERR06|Byte count mismatch"
        try:
            actual_hash = _sha256_file(session.temp_path)
        except Exception:
            self._cleanup_upload(upload_id)
            return "ERR06|Hash calculation failed"
        if session.asset_hash and actual_hash != session.asset_hash:
            self._cleanup_upload(upload_id)
            return "ERR06|Asset hash mismatch"

        user_dir = _UPLOADS_DIR_PATH / session.username
        user_dir.mkdir(parents=True, exist_ok=True)
        safe_name = _safe_asset_filename(
            session.original_name or session.asset_name,
            session.file_type,
            fallback=session.asset_name or "asset",
        )
        local_filename = f"{upload_id[:8]}_{safe_name}"
        dest_path = user_dir / local_filename
        local_rel_path = f"{session.username}/{local_filename}"  # relative path stored in DB
        try:
            shutil.move(str(session.temp_path), str(dest_path))
        except Exception as e:
            self._cleanup_upload(upload_id)
            self.binary_upload_id = None
            return f"ERR03|Local storage failed: {e}"
        drive_url = local_rel_path  # stored in DB url column as username/filename

        try:
            marketplace_db = MarketplaceDB()
            success, message, item_id = marketplace_db.add_marketplace_item(
                session.asset_name,
                session.username,
                drive_url,
                session.file_type,
                session.cost,
                session.description,
                actual_hash,
            )
        except Exception as e:
            self._cleanup_upload(upload_id)
            return f"ERR03|DB error: {e}"

        self._cleanup_upload(upload_id)
        if not success:
            return f"ERR03|{message}"
        self.Print(f" Asset uploaded: {session.asset_name} by {session.username} - ${session.cost}", 20)
        self.create_and_push_notification(
            username=session.username,
            title="Asset uploaded",
            body=f"Your asset {session.asset_name} is now in the marketplace.",
            notif_type="asset_uploaded",
            asset_id=str(item_id) if item_id else None,
        )
        # Queue mint transaction to blockchain

        mint_job = {
            'tx_type': 'mint',
            'tx_id': session.mint_tx_id,
            'owner': session.username,
            'asset_hash': actual_hash,
            'asset_name': session.asset_name,
            'timestamp': session.mint_timestamp,
            'public_key': session.public_key,
            'signature': session.mint_signature,
        }
        with self.server.tx_status_lock:
            if session.mint_tx_id in self.server.tx_status:
                self.server.tx_status[session.mint_tx_id]['status'] = 'failed'
                self.server.tx_status[session.mint_tx_id]['message'] = 'Duplicate mint tx_id'
            else:
                self.server.tx_status[session.mint_tx_id] = {
                    'status': 'queued',
                    'message': 'Queued for PoW mint',
                    'created_at': time.time(),
                    'tx_type': 'mint',
                    'asset_hash': actual_hash,
                    'asset_name': session.asset_name,
                    'owner': session.username,
                }
                self.server.tx_queue.put(mint_job)
        return f"OK|{session.asset_name}|{local_rel_path}"

    def handle_upload_abort(self, params):
        """
        Protocol: UPLOAD_ABORT - Cancel an in-progress upload.
        Format: UPLOAD_ABORT|upload_id
        """
        if len(params) < 1:
            return "ERR01|Invalid format: UPLOAD_ABORT|upload_id"
        upload_id = params[0].strip()
        self._cleanup_upload(upload_id)
        return "OK|Upload aborted"
    
    def handle_asset_list(self, params):
        """Protocol Message: GET_ITEMS - Get all marketplace items
        Format: GET_ITEMS
        Returns: OK|items_json or ERR|error_message
        """
        if not self.is_authenticated:
            return "ERR02|Not authenticated"

        try:
            import json
            items = self.db.get_all_items()
            response = f"OK|{json.dumps(items)}"
            self.Print(f" GET_ITEMS: returned {len(items)} items", 20)
            return response
        except Exception as e:
            self.Print(f"? Error processing GET_ITEMS: {e}", 40)
            return f"ERR03|Error getting items: {str(e)}"

    def handle_get_items_paginated(self, params):
        """Protocol Message: GET_ITEMS_PAGINATED - Get marketplace items with pagination
        Format: GET_ITEMS_PAGINATED|limit[|lastTimestamp] (lastTimestamp = ISO string from last item)
        """
        import json
        
        if len(params) < 1:
            self.Print(f"[RECV] GET_ITEMS_PAGINATED - Invalid format", 40)
            return "ERR01|Invalid format"
        
        try:
            limit = int(params[0].strip())
            lastTimestamp = params[1].strip() if len(params) > 1 and params[1].strip() else None
            
            self.Print(f"[RECV] GET_ITEMS_PAGINATED|{limit}|{lastTimestamp}", 20)
            
            try:
                db = MarketplaceDB()
                if lastTimestamp:
                    items = db.get_items_before_timestamp(lastTimestamp, limit)
                else:
                    items = db.get_latest_items(limit)
                
                if items:
                    items_list = items if isinstance(items[0], dict) else [
                        {'id': r[0], 'asset_name': r[1], 'description': r[2], 'username': r[3], 'url': r[4],
                         'file_type': r[5], 'cost': r[6], 'asset_hash': r[7], 'timestamp': r[8], 'created_at': r[9],
                         'is_listed': r[10]}
                        for r in items
                    ]
                    response = f"OK|{json.dumps(items_list)}"
                    self.Print(f"[SEND] OK|{len(items_list)} items", 20)
                    return response
                response = "OK|[]"
                self.Print(f"[SEND] OK|0 items (no more items)", 20)
                return response
            except Exception as db_error:
                self.Print(f" Database error: {db_error}", 40)
                return f"ERR03|Database error: {str(db_error)}"
        except ValueError as ve:
            self.Print(f"[RECV] GET_ITEMS_PAGINATED - Invalid parameters: {ve}", 40)
            return "ERR01|Invalid parameters"
        except Exception as e:
            self.Print(f" Error processing GET_ITEMS_PAGINATED: {e}", 40)
            return f"ERR99|{str(e)}"

    def handle_buy_asset(self, params):
        """
        BUY - Purchase an asset from marketplace
        Format: BUY|asset_id|username|amount|tx_id|timestamp|public_key|signature
        """
        if not self.is_authenticated:
            return "ERR03|Not authenticated"
        if len(params) < 7:
            self.Print(f"[RECV] BUY - Invalid format", 40)
            return "ERR01|Invalid format: BUY|asset_id|username|amount|tx_id|timestamp|public_key|signature"

        try:
            asset_id = params[0].strip()
            username = params[1].strip()
            amount = float(params[2].strip())
            tx_id = params[3].strip()
            timestamp = params[4].strip()
            public_key = params[5].strip()
            signature = params[6].strip()

            self.Print(f" Processing purchase: {username} buying asset {asset_id} for {amount}", 20)

            if username != self.username:
                return "ERR02|Cannot purchase on behalf of another user"

            item = self.db.get_item_by_id(asset_id)
            if not item:
                return "ERR02|Asset not found"

            seller = item.get('username')
            if seller == username:
                return "ERR02|Cannot buy your own asset"

            price = float(item.get('cost', 0))
            if abs(price - amount) > 0.01:
                return "ERR02|Price mismatch"
            if item.get('is_listed') is not None and int(item.get('is_listed')) == 0:
                return "ERR02|Asset is no longer listed"

            wallet = self.db.get_wallet(username)
            if not wallet:
                return "ERR02|Wallet not found"
            if float(wallet.get('balance', 0)) < price:
                return "ERR02|Insufficient funds"

            if not tx_id or not timestamp or not public_key or not signature:
                return "ERR02|Missing signature parameters"
            if not _is_timestamp_valid(timestamp):
                return "ERR02|Invalid or stale timestamp"
            if not self.db.set_user_public_key(username, public_key):
                return "ERR02|Public key mismatch"

            asset_hash = item.get('asset_hash')
            if not asset_hash:
                return "ERR02|Asset missing verified hash"
            tx_payload = {
                'action': 'purchase',
                'tx_id': tx_id,
                'asset_id': asset_id,
                'asset_hash': asset_hash,
                'asset_name': item.get('asset_name'),
                'price': price,
                'from': username,
                'to': seller,
                'amount': price,
                'timestamp': timestamp,
            }
            msg_bytes = _canonical_tx_message(username, tx_payload)
            if not _verify_ed25519_signature(public_key, msg_bytes, signature):
                return "ERR02|Invalid signature"

            purchase = {
                'tx_id': tx_id,
                'buyer': username,
                'seller': seller,
                'asset_id': asset_id,
                'asset_hash': asset_hash,
                'asset_name': item.get('asset_name'),
                'amount': price,
                'timestamp': timestamp,
                'public_key': public_key,
                'signature': signature,
            }

            with self.server.tx_status_lock:
                if tx_id in self.server.tx_status:
                    return "ERR02|Duplicate tx_id"
                self.server.tx_status[tx_id] = {
                    'status': 'queued',
                    'message': 'Queued for PoW',
                    'created_at': time.time(),
                    'asset_id': asset_id,
                    'asset_name': item.get('asset_name'),
                    'buyer': username,
                    'seller': seller,
                    'amount': price,
                    'tx_type': 'purchase',
                }
            self.server.tx_queue.put(purchase)

            self.Print(f" Purchase queued for PoW: {tx_id}", 20)
            return f"OK|PENDING|{tx_id}"

        except ValueError as ve:
            self.Print(f"[RECV] BUY - Invalid parameters: {ve}", 40)
            return "ERR01|Invalid amount format"
        except Exception as e:
            self.Print(f" Error processing BUY: {e}", 40)
            return f"ERR99|{str(e)}"

    def handle_send_asset(self, params):
        """
        SEND - Send purchased asset to another user
        Format: SEND|asset_id|sender_username|receiver_username|tx_id|timestamp|public_key|signature
        """
        if not self.is_authenticated:
            return "ERR02|Not authenticated"
        if len(params) < 7:
            self.Print(f"[RECV] SEND - Invalid format", 40)
            return "ERR01|Invalid format: SEND|asset_id|sender|receiver|tx_id|timestamp|public_key|signature"
        
        try:
            asset_id = params[0].strip()
            sender_username = params[1].strip()
            receiver_username = params[2].strip()
            tx_id = params[3].strip()
            timestamp = params[4].strip()
            public_key = params[5].strip()
            signature = params[6].strip()

            if not asset_id or not sender_username or not receiver_username:
                return "ERR01|Invalid parameters"
            if sender_username != self.username:
                return "ERR02|Unauthorized"
            if sender_username == receiver_username:
                return "ERR02|Cannot send to yourself"

            item = self.db.get_item_by_id(asset_id)
            if not item:
                return "ERR02|Asset not found"
            if item.get('username') != sender_username:
                return "ERR02|Sender does not own asset"
            if item.get('is_listed') is not None and int(item.get('is_listed')) == 1:
                return "ERR02|Asset is listed for sale. Unlist before sending"

            receiver = self.db.get_user(receiver_username)
            if not receiver:
                return "ERR02|Receiver not found"

            if not tx_id or not timestamp or not public_key or not signature:
                return "ERR02|Missing signature parameters"
            if not _is_timestamp_valid(timestamp):
                return "ERR02|Invalid or stale timestamp"
            if not self.db.set_user_public_key(sender_username, public_key):
                return "ERR02|Public key mismatch"
            asset_hash = item.get('asset_hash')
            if not asset_hash:
                return "ERR02|Asset missing verified hash"
            tx_payload = {
                'action': 'asset_transfer',
                'tx_id': tx_id,
                'asset_id': asset_id,
                'asset_hash': asset_hash,
                'asset_name': item.get('asset_name'),
                'from': sender_username,
                'to': receiver_username,
                'amount': 0,
                'timestamp': timestamp,
            }
            msg_bytes = _canonical_tx_message(sender_username, tx_payload)
            if not _verify_ed25519_signature(public_key, msg_bytes, signature):
                return "ERR02|Invalid signature"

            self.Print(f" Processing asset send: {sender_username} -> {receiver_username} (asset: {asset_id})", 20)

            transfer = {
                'tx_id': tx_id,
                'tx_type': 'transfer',
                'from': sender_username,
                'to': receiver_username,
                'asset_id': asset_id,
                'asset_hash': asset_hash,
                'asset_name': item.get('asset_name'),
                'amount': 0,
                'timestamp': timestamp,
                'public_key': public_key,
                'signature': signature,
            }

            with self.server.tx_status_lock:
                if tx_id in self.server.tx_status:
                    return "ERR02|Duplicate tx_id"
                self.server.tx_status[tx_id] = {
                    'status': 'queued',
                    'message': 'Queued for PoW transfer',
                    'created_at': time.time(),
                    'asset_id': asset_id,
                    'asset_name': item.get('asset_name'),
                    'tx_type': 'transfer',
                    'sender': sender_username,
                    'receiver': receiver_username,
                }
            self.server.tx_queue.put(transfer)

            self.Print(f" Asset transfer queued for PoW: {tx_id}", 20)
            return f"OK|PENDING|{tx_id}"
            
        except Exception as e:
            self.Print(f" Error processing SEND: {e}", 40)
            return f"ERR99|{str(e)}"

    def handle_get_profile(self, params):
        """
        GET_PROFILE - Get user profile (anonymous)
        Format: GET_PROFILE|username
        Returns: OK|username|email|created_at or ERR|error_message
        """
        if len(params) < 1:
            self.Print(f"[RECV] GET_PROFILE - Invalid format", 40)
            return "ERR01|Invalid format: GET_PROFILE|username"
        try:
            username = params[0].strip()
            if not username or '|' in username:
                self.Print(f" Invalid username format", 40)
                return "ERR01|Invalid username"
            user_obj = self.db.get_user(username)
            if not user_obj:
                self.Print(f" User {username} not found", 40)
                return "ERR02|User not found"
            self.Print(f" Profile retrieved for {username}", 20)
            return f"OK|{username}|{user_obj.email}|{user_obj.created_at}"
        except Exception as e:
            self.Print(f" Error processing GET_PROFILE: {e}", 40)
            return f"ERR99|{str(e)}"

    def handle_get_tx_status(self, params):
        """
        GET_TX_STATUS - Check transaction status
        Format: GET_TX_STATUS|tx_id
        Returns: OK|STATUS|message or ERR|error_message
        """
        if len(params) < 1:
            return "ERR01|Invalid format: GET_TX_STATUS|tx_id"
        tx_id = params[0].strip()
        if not tx_id:
            return "ERR01|Invalid tx_id"

        info = self.server._get_tx_info(tx_id)
        if not info:
            return "ERR02|Transaction not found"

        status = info.get('status', 'unknown')
        message = info.get('message', '')
        created_at = info.get('created_at', time.time())

        if status in ('queued', 'submitted'):
            if time.time() - created_at > self.server.tx_timeout_seconds:
                status = 'timeout'
                message = 'PoW Timeout after 10 mins'
                self.server._set_tx_status(tx_id, status, message)

        return f"OK|{status.upper()}|{message}"

    def handle_get_items_by_user(self, params):
        """
        GET_ITEMS_BY_USER - Get assets owned by a user
        Format: GET_ITEMS_BY_USER|username
        Returns: OK|items_json or ERR|error_message
        """
        if not self.is_authenticated:
            return "ERR02|Not authenticated"
        if len(params) < 1:
            return "ERR01|Invalid format: GET_ITEMS_BY_USER|username"
        username = params[0].strip()
        if not username or '|' in username:
            return "ERR01|Invalid username"
        if username != self.username:
            return "ERR02|Unauthorized"
        try:
            items = self.db.get_items_by_username(username)
            return f"OK|{json.dumps(items)}"
        except Exception as e:
            return f"ERR03|Error getting items: {str(e)}"

    def handle_get_wallet(self, params):
        """
        GET_WALLET - Get wallet balance for a user
        Format: GET_WALLET|username
        Returns: OK|balance|updated_at or ERR|error_message
        """
        if not self.is_authenticated:
            return "ERR02|Not authenticated"
        if len(params) < 1:
            return "ERR01|Invalid format: GET_WALLET|username"

        username = params[0].strip()
        if not username or '|' in username:
            return "ERR01|Invalid username"
        if username != self.username:
            return "ERR02|Unauthorized"

        try:
            self.db.ensure_wallet(username, 100)
            wallet = self.db.get_wallet(username)
            if not wallet:
                return "ERR02|Wallet not found"
            balance = wallet.get('balance', 0)
            updated_at = wallet.get('updated_at') or ''
            return f"OK|{balance}|{updated_at}"
        except Exception as e:
            return f"ERR03|Error getting wallet: {str(e)}"

    def handle_get_notifications(self, params):
        """
        GET_NOTIFICATIONS - Get notifications for a user
        Format: GET_NOTIFICATIONS|username|limit
        Returns: OK|json_list|unread_count or ERR|error_message
        """
        if not self.is_authenticated:
            return "ERR02|Not authenticated"
        if len(params) < 1:
            return "ERR01|Invalid format: GET_NOTIFICATIONS|username|limit"
        username = params[0].strip()
        if not username or '|' in username:
            return "ERR01|Invalid username"
        if username != self.username:
            return "ERR02|Unauthorized"
        limit = 20
        if len(params) >= 2:
            try:
                limit = int(params[1])
            except Exception:
                limit = 20
        try:
            items = self.notifications_manager.get_notifications(username, limit=limit)
            unread_count = self.notifications_manager.get_unread_count(username)
            payload = [
                n.to_dict() if hasattr(n, "to_dict") else n
                for n in items
            ]
            return f"OK|{json.dumps(payload)}|{unread_count}"
        except Exception as e:
            return f"ERR03|Error getting notifications: {str(e)}"

    def handle_mark_notifications_read(self, params):
        """
        MARK_NOTIFICATIONS_READ - Mark all notifications as read for a user
        Format: MARK_NOTIFICATIONS_READ|username
        Returns: OK|read or ERR|error_message
        """
        if not self.is_authenticated:
            return "ERR02|Not authenticated"
        if len(params) < 1:
            return "ERR01|Invalid format: MARK_NOTIFICATIONS_READ|username"
        username = params[0].strip()
        if not username or '|' in username:
            return "ERR01|Invalid username"
        if username != self.username:
            return "ERR02|Unauthorized"
        try:
            self.notifications_manager.mark_read(username)
            return "OK|read"
        except Exception as e:
            return f"ERR03|Error marking notifications: {str(e)}"

    def handle_register_device(self, params):
        """
        REGISTER_DEVICE - Register push notification token
        Format: REGISTER_DEVICE|username|platform|token
        Returns: OK|registered or ERR|error_message
        """
        if not self.is_authenticated:
            return "ERR02|Not authenticated"
        if len(params) < 3:
            return "ERR01|Invalid format: REGISTER_DEVICE|username|platform|token"

        username = params[0].strip()
        platform = params[1].strip().lower()
        token = params[2].strip()

        if not username or not token or '|' in username or '|' in token:
            return "ERR01|Invalid parameters"
        if username != self.username:
            return "ERR02|Unauthorized"

        if len(token) < 10:
            return "ERR01|Invalid token"
        if platform not in ("android", "ios", "web"):
            platform = "unknown"

        ok = self.db.upsert_device_token(username, token, platform)
        if not ok:
            return "ERR03|Failed to register device"
        return "OK|registered"

    def handle_list_item(self, params):
        """
        LIST_ITEM - List an owned asset for sale
        Format: LIST_ITEM|asset_id|username|price
        Returns: OK|LISTED or ERR|error_message
        """
        if not self.is_authenticated:
            return "ERR02|Not authenticated"
        if len(params) < 3:
            return "ERR01|Invalid format: LIST_ITEM|asset_id|username|price"

        asset_id = params[0].strip()
        username = params[1].strip()
        price_str = params[2].strip()

        if not asset_id or not username or '|' in username:
            return "ERR01|Invalid parameters"
        if username != self.username:
            return "ERR02|Unauthorized"

        try:
            price = float(price_str)
        except Exception:
            return "ERR01|Invalid price format"
        if price <= 0:
            return "ERR01|Price must be positive"

        item = self.db.get_item_by_id(asset_id)
        if not item:
            return "ERR02|Asset not found"
        if item.get('username') != username:
            return "ERR02|Unauthorized"

        updated = self.db.update_item_listing(asset_id, True, new_cost=price)
        if updated:
            return "OK|LISTED"
        return "ERR03|Failed to list item"

    def handle_unlist_item(self, params):
        """
        UNLIST_ITEM - Remove an asset from marketplace listing
        Format: UNLIST_ITEM|asset_id|username
        Returns: OK|UNLISTED or ERR|error_message
        """
        if not self.is_authenticated:
            return "ERR02|Not authenticated"
        if len(params) < 2:
            return "ERR01|Invalid format: UNLIST_ITEM|asset_id|username"

        asset_id = params[0].strip()
        username = params[1].strip()

        if not asset_id or not username or '|' in username:
            return "ERR01|Invalid parameters"
        if username != self.username:
            return "ERR02|Unauthorized"

        item = self.db.get_item_by_id(asset_id)
        if not item:
            return "ERR02|Asset not found"
        if item.get('username') != username:
            return "ERR02|Unauthorized"

        updated = self.db.update_item_listing(asset_id, False)
        if updated:
            self.server.broadcast_marketplace_remove(asset_id)
            return "OK|UNLISTED"
        return "ERR03|Failed to unlist item"


class Server:
    """Main server that handles all client connections"""
    
    def __init__(self, host=SERVER_HOST, port=SERVER_PORT, logging_level=LOGGING_LEVEL):
        self.host = host
        self.port = port
        self.server_ip = _resolve_server_ip(SERVER_IP, host)  # Broadcast response IP
        self.logging_level = logging_level
        self.logger = CustomLogger("Server", logging_level)
        self.Print = self.logger.Print
        
        self.clients_lock = threading.Lock()
        self.clients = {}  # addr -> ClientSession
        self.clients_by_username = {}  # username -> set(ClientSession)
        self.is_running = False
        self.db = MarketplaceDB()
        self.notifications_manager = NotificationsManager()
        self.upload_sessions = {}
        self.upload_sessions_lock = threading.Lock()

        # Purchase -> gateway queue + status tracking
        self.tx_queue = queue.Queue()
        self.tx_status = {}
        self.tx_status_lock = threading.Lock()
        self.tx_timeout_seconds = 600  # 10 minutes

        # Start background worker for gateway submissions
        worker = threading.Thread(target=self._tx_worker, daemon=True)
        worker.start()
        # Start timeout monitor for queued/submitted purchases
        timeout_worker = threading.Thread(target=self._tx_timeout_worker, daemon=True)
        timeout_worker.start()

    def register_authenticated_session(self, session):
        """Track authenticated sessions for notifications/broadcasts."""
        if not session or not session.username:
            return
        with self.clients_lock:
            sessions = self.clients_by_username.setdefault(session.username, set())
            sessions.add(session)

    def unregister_session(self, session, username=None):
        """Remove session from tracking structures."""
        if not session and not username:
            return
        uname = username or getattr(session, 'username', None)
        with self.clients_lock:
            if uname and uname in self.clients_by_username:
                try:
                    self.clients_by_username[uname].discard(session)
                    if not self.clients_by_username[uname]:
                        del self.clients_by_username[uname]
                except Exception:
                    pass

    def _send_event(self, session, event_payload):
        """Send an async event to a single session."""
        if not session:
            return
        try:
            raw = f"EVENT|{json.dumps(event_payload)}".encode()
            session.proto.send_one_message(raw)
        except Exception as e:
            server_logger.warning("event send failed: %s", e)

    def send_event_to_user(self, username, event_payload):
        """Send an async event to all active sessions for a user."""
        if not username:
            return
        with self.clients_lock:
            sessions = list(self.clients_by_username.get(username, set()))
        for session in sessions:
            self._send_event(session, event_payload)

    def broadcast_event(self, event_payload):
        """Broadcast an async event to all connected sessions."""
        with self.clients_lock:
            sessions = list(self.clients.values())
        for session in sessions:
            self._send_event(session, event_payload)

    def broadcast_marketplace_remove(self, asset_id):
        payload = {
            'event': 'marketplace_remove',
            'payload': {'asset_id': str(asset_id)},
        }
        self.broadcast_event(payload)

    def create_and_push_notification(self, username, title, body, notif_type="system", asset_id=None, tx_id=None):
        notif = self.notifications_manager.create_notification(
            username=username,
            title=title,
            body=body,
            notif_type=notif_type,
            asset_id=asset_id,
            tx_id=tx_id,
        )
        if notif:
            payload_notif = notif.to_dict() if hasattr(notif, "to_dict") else notif
            payload = {
                'event': 'notification',
                'payload': payload_notif,
            }
            self.send_event_to_user(username, payload)
            if FCM_ENABLED and FCM_SERVER_KEY:
                threading.Thread(
                    target=self._send_push_notification,
                    args=(username, title, body, notif_type, asset_id, tx_id),
                    daemon=True,
                ).start()
        return notif

    def _send_push_notification(self, username, title, body, notif_type, asset_id=None, tx_id=None):
        """Send push notification via FCM to all devices for a user."""
        try:
            tokens = self.db.get_device_tokens(username)
            if not tokens:
                return
            payload = {
                "registration_ids": tokens,
                "priority": "high",
                "notification": {
                    "title": title,
                    "body": body,
                },
                "data": {
                    "type": notif_type or "system",
                    "title": title,
                    "body": body,
                    "asset_id": asset_id or "",
                    "tx_id": tx_id or "",
                },
            }
            resp = self._post_fcm(payload)
            if not resp or not isinstance(resp, dict):
                return
            results = resp.get("results") or []
            invalid = []
            for token, result in zip(tokens, results):
                error = result.get("error")
                if error in ("NotRegistered", "InvalidRegistration", "MismatchSenderId"):
                    invalid.append(token)
            for token in invalid:
                self.db.delete_device_token(token)
        except Exception as e:
            server_logger.warning("push send failed: %s", e)

    def _post_fcm(self, payload):
        """Send raw payload to FCM legacy HTTP API."""
        if not FCM_SERVER_KEY:
            return None
        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                "https://fcm.googleapis.com/fcm/send",
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"key={FCM_SERVER_KEY}",
                },
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                body = resp.read().decode("utf-8")
            if not body:
                return {}
            return json.loads(body)
        except urllib.error.HTTPError as e:
            try:
                err_body = e.read().decode("utf-8")
                server_logger.warning("FCM HTTP error %s: %s", e.code, err_body)
            except Exception:
                server_logger.warning("FCM HTTP error %s", e.code)
            return None
        except Exception as e:
            server_logger.warning("FCM send error: %s", e)
            return None

    def _emit_tx_notifications(self, tx_id, info):
        tx_type = info.get('tx_type', 'purchase')
        status = info.get('status')
        asset_id = info.get('asset_id')
        asset_name = info.get('asset_name') or (f"asset {asset_id}" if asset_id else "asset")
        message = info.get('message') or ''

        if tx_type == 'transfer':
            sender = info.get('sender')
            receiver = info.get('receiver')
            if status == 'confirmed':
                if receiver:
                    self.create_and_push_notification(
                        username=receiver,
                        title="Asset received",
                        body=f"You received {asset_name} from {sender or 'another user'}.",
                        notif_type="asset_received",
                        asset_id=asset_id,
                        tx_id=tx_id,
                    )
                if sender:
                    self.create_and_push_notification(
                        username=sender,
                        title="Asset sent",
                        body=f"Your asset {asset_name} was sent to {receiver or 'another user'}.",
                        notif_type="asset_sent",
                        asset_id=asset_id,
                        tx_id=tx_id,
                    )
            elif status in ('failed', 'timeout'):
                if sender:
                    detail = message if message else f"Your transfer of {asset_name} failed."
                    self.create_and_push_notification(
                        username=sender,
                        title="Transfer failed",
                        body=detail,
                        notif_type="asset_transfer_failed",
                        asset_id=asset_id,
                        tx_id=tx_id,
                    )
            return

        buyer = info.get('buyer')
        seller = info.get('seller')
        if status == 'confirmed':
            if asset_id:
                self.db.set_item_listed(asset_id, False)
                self.broadcast_marketplace_remove(asset_id)
            if buyer:
                self.create_and_push_notification(
                    username=buyer,
                    title="Purchase confirmed",
                    body=f"Your purchase of {asset_name} is confirmed.",
                    notif_type="purchase_confirmed",
                    asset_id=asset_id,
                    tx_id=tx_id,
                )
            if seller:
                self.create_and_push_notification(
                    username=seller,
                    title="Asset sold",
                    body=f"{buyer} bought your asset {asset_name}.",
                    notif_type="asset_sold",
                    asset_id=asset_id,
                    tx_id=tx_id,
                )
        elif status in ('failed', 'timeout'):
            if buyer:
                detail = message if message else f"Your purchase of {asset_name} failed."
                self.create_and_push_notification(
                    username=buyer,
                    title="Purchase failed",
                    body=detail,
                    notif_type="purchase_failed",
                    asset_id=asset_id,
                    tx_id=tx_id,
                )
    def _start_broadcast_listener(self):
        """Start listening for WHRSRV (Where's Server) broadcast queries"""
        def broadcast_loop():
            try:
                # Create UDP socket for broadcast listening
                broadcast_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                broadcast_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                broadcast_sock.settimeout(1.0)  # 1 second timeout to allow checking is_running
                broadcast_sock.bind(('0.0.0.0', BROADCAST_PORT))
                
                self.Print(f" Broadcast listener started on port {BROADCAST_PORT}", 20)
                
                while self.is_running:
                    try:
                        data, addr = broadcast_sock.recvfrom(1024)
                        message = data.decode('utf-8').strip()
                        
                        if message == "WHRSRV":
                            response = f"SRVRSP|{self.server_ip}|{self.port}"
                            broadcast_sock.sendto(response.encode('utf-8'), addr)
                            self.Print(f" Broadcast response sent to {addr}: {response}", 10)
                    except socket.timeout:
                        continue
                    except Exception as e:
                        self.Print(f" Broadcast listener error: {e}", 10)
                
                broadcast_sock.close()
            except Exception as e:
                self.Print(f" Failed to start broadcast listener: {e}", 10)
        
        # Start broadcast listener in a separate thread
        thread = threading.Thread(target=broadcast_loop, daemon=True)
        thread.start()

    def _start_block_confirmation_listener(self):
        """Background listener: receive block_confirmation from RPC server (blockchain)."""
        def listen_loop():
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(('0.0.0.0', BLOCK_CONFIRMATION_PORT))
                sock.listen(5)
                sock.settimeout(1.0)
                self.Print(" Block confirmation listener on port %s" % BLOCK_CONFIRMATION_PORT, 20)
                while self.is_running:
                    try:
                        client, addr = sock.accept()
                        client.settimeout(5)
                        data = b''
                        while b'\n' not in data and len(data) < 65536:
                            chunk = client.recv(4096)
                            if not chunk:
                                break
                            data += chunk
                        client.close()
                        if data:
                            line = data.decode('utf-8', errors='ignore').strip()
                            if line:
                                msg = json.loads(line)
                                if msg.get('type') == 'block_confirmation':
                                    server_logger.info(
                                        "block_confirmation block_index=%s block_hash=%s miner_id=%s",
                                        msg.get('block_index'), msg.get('block_hash', '')[:16], msg.get('miner_id')
                                    )
                                    self.Print(" Block confirmed: index=%s hash=%s..." % (
                                        msg.get('block_index'), (msg.get('block_hash') or '')[:16]), 20)
                                    # Apply wallet transfers from confirmed transactions
                                    for tx in msg.get('transactions', []):
                                        data = tx.get('data') if isinstance(tx.get('data'), dict) else {}
                                        action = data.get('action')
                                        from_user = data.get('from') or tx.get('sender')
                                        to_user = data.get('to')
                                        amount = data.get('amount') if data.get('amount') is not None else data.get('price')
                                        asset_id = data.get('asset_id')
                                        asset_hash = data.get('asset_hash')
                                        tx_id = data.get('tx_id')
                                        if action == 'asset_mint':
                                            if tx_id:
                                                self._set_tx_status(tx_id, "confirmed", "Mint confirmed")
                                            continue
                                        if action == 'purchase':
                                            buyer = from_user
                                            seller = to_user
                                            try:
                                                amt = float(amount) if amount is not None else None
                                            except (ValueError, TypeError):
                                                amt = None
                                            if not buyer or not seller or amt is None:
                                                if tx_id:
                                                    self._set_tx_status(tx_id, "failed", "Invalid purchase payload")
                                                continue
                                            ok, res = self.db.transfer(buyer, seller, amt)
                                            if ok:
                                                new_owner = buyer
                                                updated = False
                                                if asset_id:
                                                    updated = self.db.update_asset_owner(str(asset_id), new_owner)
                                                if not updated and asset_hash:
                                                    updated = self.db.update_asset_owner_by_hash(asset_hash, new_owner)
                                                if updated:
                                                    server_logger.info(
                                                        "purchase: asset_id=%s new_owner=%s", asset_id, new_owner
                                                    )
                                                    if tx_id:
                                                        self._set_tx_status(tx_id, "confirmed", "Transaction confirmed")
                                                else:
                                                    server_logger.warning(
                                                        "purchase: ownership update failed asset_id=%s", asset_id
                                                    )
                                                    if tx_id:
                                                        self._set_tx_status(
                                                            tx_id, "failed", "Asset ownership update failed"
                                                        )
                                            else:
                                                server_logger.warning("purchase: wallet transfer failed: %s", res)
                                                if tx_id:
                                                    self._set_tx_status(tx_id, "failed", res)
                                            continue
                                        if action == 'asset_transfer':
                                            if from_user and to_user and (asset_id or asset_hash):
                                                updated = False
                                                if asset_hash:
                                                    updated = self.db.update_asset_owner_by_hash(asset_hash, to_user)
                                                if not updated and asset_id:
                                                    updated = self.db.update_asset_owner(asset_id, to_user)
                                                if updated:
                                                    if asset_id:
                                                        self.db.set_item_listed(asset_id, False)
                                                        self.broadcast_marketplace_remove(asset_id)
                                                    server_logger.info(
                                                        "asset transfer updated: asset_id=%s owner=%s", asset_id, to_user
                                                    )
                                                else:
                                                    server_logger.warning(
                                                        "asset transfer update failed: asset_id=%s", asset_id
                                                    )
                                                if tx_id:
                                                    self._set_tx_status(tx_id, "confirmed", "Transfer confirmed")
                                            else:
                                                if tx_id:
                                                    self._set_tx_status(tx_id, "failed", "Invalid transfer payload")
                                            continue
                                        if from_user and to_user is not None and amount is not None:
                                            try:
                                                amount = float(amount)
                                                ok, res = self.db.transfer(from_user, to_user, amount)
                                                if ok:
                                                    server_logger.info("wallet transfer: %s -> %s amount=%s: %s", from_user, to_user, amount, res)
                                                    self.Print(" Saved: %s" % res, 20)
                                                    wa, wb = self.db.get_wallet(from_user), self.db.get_wallet(to_user)
                                                    if wa and wb:
                                                        server_logger.info("balances: %s=%.2f %s=%.2f", from_user, wa['balance'], to_user, wb['balance'])
                                                    if asset_id or asset_hash:
                                                        updated = False
                                                        if asset_id:
                                                            updated = self.db.update_asset_owner(asset_id, to_user)
                                                        if not updated and asset_hash:
                                                            updated = self.db.update_asset_owner_by_hash(asset_hash, to_user)
                                                        if updated:
                                                            server_logger.info("asset ownership updated: asset_id=%s owner=%s", asset_id, to_user)
                                                        else:
                                                            server_logger.warning("asset ownership update failed: asset_id=%s", asset_id)
                                                    if tx_id:
                                                        self._set_tx_status(tx_id, "confirmed", "Transaction confirmed")
                                                else:
                                                    server_logger.warning("wallet transfer failed: %s", res)
                                                    if tx_id:
                                                        self._set_tx_status(tx_id, "failed", res)
                                            except (ValueError, TypeError) as e:
                                                server_logger.warning("skip tx (bad amount): %s", e)
                    except socket.timeout:
                        continue
                    except json.JSONDecodeError as e:
                        server_logger.warning("block_confirmation parse error: %s", e)
                    except Exception as e:
                        if self.is_running:
                            server_logger.warning("block_confirmation listener: %s", e)
                sock.close()
            except Exception as e:
                server_logger.error("block_confirmation listener failed: %s", e)
        thread = threading.Thread(target=listen_loop, daemon=True)
        thread.start()

    def _set_tx_status(self, tx_id, status, message=None):
        emit_info = None
        with self.tx_status_lock:
            info = self.tx_status.get(tx_id)
            if not info:
                self.tx_status[tx_id] = {
                    'status': status,
                    'message': message or '',
                    'created_at': time.time(),
                }
                info = self.tx_status[tx_id]
            else:
                info['status'] = status
                if message is not None:
                    info['message'] = message
            if status in ('confirmed', 'failed', 'timeout') and not info.get('notified'):
                info['notified'] = True
                emit_info = dict(info)
        if emit_info:
            self._emit_tx_notifications(tx_id, emit_info)

    def _get_tx_info(self, tx_id):
        with self.tx_status_lock:
            info = self.tx_status.get(tx_id)
            return dict(info) if info else None

    def _tx_timeout_worker(self):
        while True:
            time.sleep(5)
            now = time.time()
            to_timeout = []
            with self.tx_status_lock:
                for tx_id, info in list(self.tx_status.items()):
                    status = info.get('status')
                    created_at = info.get('created_at', now)
                    if status in ('queued', 'submitted') and now - created_at > self.tx_timeout_seconds:
                        to_timeout.append(tx_id)
            for tx_id in to_timeout:
                self._set_tx_status(tx_id, 'timeout', 'PoW Timeout after 10 mins')

    def _tx_worker(self):
        while True:
            tx_job = self.tx_queue.get()
            if not tx_job:
                self.tx_queue.task_done()
                continue
            tx_id = tx_job.get('tx_id')
            tx_type = tx_job.get('tx_type', 'purchase')
            try:
                if tx_type == 'transfer':
                    response = self._submit_transfer_to_gateway(tx_job)
                elif tx_type == 'mint':
                    response = self._submit_mint_to_gateway(tx_job)
                else:
                    response = self._submit_purchase_to_gateway(tx_job)
                if response and response.get('status') == 'submitted':
                    self._set_tx_status(tx_id, "submitted", response.get('message', 'Submitted to gateway'))
                else:
                    msg = response.get('message') if response else "Gateway did not respond"
                    self._set_tx_status(tx_id, "failed", msg)
            except Exception as e:
                self._set_tx_status(tx_id, "failed", f"Gateway error: {e}")
            finally:
                self.tx_queue.task_done()

    def _submit_purchase_to_gateway(self, purchase):
        payload = {
            'action': 'submit_purchase',
            'body': {
                'tx_id': purchase.get('tx_id'),
                'buyer': purchase.get('buyer'),
                'seller': purchase.get('seller'),
                'asset_id': purchase.get('asset_id'),
                'asset_hash': purchase.get('asset_hash'),
                'asset_name': purchase.get('asset_name'),
                'price': purchase.get('amount'),
                'timestamp': purchase.get('timestamp'),
                'public_key': purchase.get('public_key'),
                'signature': purchase.get('signature'),
            }
        }
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        sock.connect((GATEWAY_HOST, GATEWAY_PORT))
        raw = json.dumps(payload).encode()
        sock.send(struct.pack('>H', len(raw)) + raw)
        response = self._recv_gateway_json(sock)
        sock.close()
        return response

    def _submit_transfer_to_gateway(self, transfer):
        tx_payload = {
            'action': 'asset_transfer',
            'tx_id': transfer.get('tx_id'),
            'asset_id': transfer.get('asset_id'),
            'asset_hash': transfer.get('asset_hash'),
            'asset_name': transfer.get('asset_name'),
            'from': transfer.get('from'),
            'to': transfer.get('to'),
            'amount': transfer.get('amount', 0),
            'timestamp': transfer.get('timestamp'),
        }
        payload = {
            'action': 'submit_transaction',
            'body': {
                'sender': transfer.get('from'),
                'data': tx_payload,
                'signature': transfer.get('signature'),
                'public_key': transfer.get('public_key'),
            }
        }
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        sock.connect((GATEWAY_HOST, GATEWAY_PORT))
        raw = json.dumps(payload).encode()
        sock.send(struct.pack('>H', len(raw)) + raw)
        response = self._recv_gateway_json(sock)
        sock.close()
        return response

    def _submit_mint_to_gateway(self, mint):
        tx_payload = {
            'action': 'asset_mint',
            'tx_id': mint.get('tx_id'),
            'asset_hash': mint.get('asset_hash'),
            'asset_name': mint.get('asset_name'),
            'owner': mint.get('owner'),
            'owner_pub': mint.get('public_key'),
            'timestamp': mint.get('timestamp'),
        }
        payload = {
            'action': 'submit_transaction',
            'body': {
                'sender': mint.get('owner'),
                'data': tx_payload,
                'signature': mint.get('signature'),
                'public_key': mint.get('public_key'),
            }
        }
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        sock.connect((GATEWAY_HOST, GATEWAY_PORT))
        raw = json.dumps(payload).encode()
        sock.send(struct.pack('>H', len(raw)) + raw)
        response = self._recv_gateway_json(sock)
        sock.close()
        return response

    def _recv_gateway_json(self, sock, max_size=65536):
        len_buf = sock.recv(2)
        if len(len_buf) < 2:
            return None
        size = struct.unpack('>H', len_buf)[0]
        if size > max_size:
            return None
        data = b''
        while len(data) < size:
            chunk = sock.recv(min(size - len(data), 4096))
            if not chunk:
                return None
            data += chunk
        try:
            return json.loads(data.decode())
        except Exception:
            return None
    
    def start(self):
        """Start the server"""
        self.Print(f" Server starting on {self.host}:{self.port}...", 20)
        
        try:
            self.is_running = True
            
            # Start broadcast listener thread
            self._start_broadcast_listener()
            # Start block confirmation listener (RPC -> server)
            self._start_block_confirmation_listener()
            
            # Create SSL context
            context = ssl_module.SSLContext(ssl_module.PROTOCOL_TLS_SERVER)
            cert_path = _resolve_path(SSL_CERT_FILE)
            key_path = _resolve_path(SSL_KEY_FILE)
            context.load_cert_chain(certfile=cert_path, keyfile=key_path)
            
            # Create socket
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind((self.host, self.port))
                sock.listen(5)
                
                self.Print(f" Server listening on {self.host}:{self.port}", 20)
                
                while self.is_running:
                    try:
                        # Accept connection
                        client_sock, addr = sock.accept()
                        
                        self.Print(f" Connection attempt from {addr[0]}:{addr[1]}", 20)
                        
                        # Wrap with SSL
                        try:
                            ssl_sock = context.wrap_socket(
                                client_sock,
                                server_side=True
                            )
                            # Keep socket blocking (no timeout) for persistent connections
                            ssl_sock.setblocking(True)
                            self.Print(f" SSL/TLS handshake successful for {addr[0]}:{addr[1]}", 20)
                        except Exception as ssl_err:
                            self.Print(f" SSL error for {addr[0]}:{addr[1]}: {ssl_err}", 40)
                            ssl_sock = client_sock  # Fallback to plain socket
                            ssl_sock.setblocking(True)
                        
                        # Handle client in separate thread (non-blocking)
                        client_thread = threading.Thread(
                            target=self.handle_client,
                            args=(ssl_sock, addr),
                            daemon=True
                        )
                        client_thread.start()
                    except KeyboardInterrupt:
                        self.Print(" Server shutting down...", 20)
                        self.is_running = False
                    except Exception as e:
                        self.Print(f" Error accepting connection: {e}", 40)
        
        except Exception as e:
            self.Print(f" Critical server error: {e}", 40)
        finally:
            self.Print(f" Server shutdown complete", 20)
    
    def handle_client(self, sock, addr):
        """Handle a single client connection (non-blocking event loop)"""
        session = None
        try:
            self.Print(f" Client connected {addr[0]}:{addr[1]} (session ready)", 20)
            
            # Create session for this client
            session = ClientSession(sock, addr, self.logging_level, server=self)
            with self.clients_lock:
                self.clients[addr] = session
            
            # Receive messages until client disconnects
            while session.is_connected:
                try:
                    message = session.proto.recv_one_message()
                    
                    if message is None:
                        self.Print(f" Client {addr[0]}:{addr[1]} disconnected (recv returned None)", 20)
                        session.is_connected = False
                        break
                    
                    try:
                        # Inline binary upload chunk: UPLOAD_CHUNK|{upload_id}|{4-byte-seq}{raw-data}
                        # Detected before UTF-8 decode to avoid failures on binary payload.
                        if isinstance(message, bytes) and message.startswith(b"UPLOAD_CHUNK|"):
                            try:
                                parts = message.split(b"|", 2)
                                if len(parts) != 3 or len(parts[2]) < 4:
                                    response = "ERR|INVALID_ID"
                                else:
                                    upload_id = parts[1].decode('ascii').strip()
                                    if not upload_id or upload_id == "[]":
                                        response = "ERR|INVALID_ID"
                                    else:
                                        seq = struct.unpack('!I', parts[2][:4])[0]
                                        chunk_data = parts[2][4:]
                                        response = session._handle_binary_chunk_inline(upload_id, seq, chunk_data)
                            except Exception as chunk_err:
                                self.Print(f" Malformed binary chunk from {addr[0]}:{addr[1]}: {chunk_err}", 40)
                                response = "ERR|INVALID_ID"
                            self.Print(f" {addr[0]}:{addr[1]} -> {response[:80]}", 10)
                            session.proto.send_one_message(response.encode())
                            continue

                        msg_str = message.decode() if isinstance(message, bytes) else message
                        log_msg = "UPLOAD_INIT|<payload>" if msg_str.startswith("UPLOAD_INIT|") else msg_str
                        self.Print(f" {addr[0]}:{addr[1]} <- {log_msg}", 20)

                        response = session.process_message(msg_str)

                        if response is not None:
                            resp_preview = response if len(response) < 200 else f"{response[:197]}..."
                            self.Print(f" {addr[0]}:{addr[1]} -> {resp_preview}", 20)
                            session.proto.send_one_message(response.encode())
                    
                    except Exception as e:
                        self.Print(f" Error processing message from {addr[0]}:{addr[1]}: {e}", 40)
                        try:
                            session.proto.send_one_message(f"ERR99|{str(e)}".encode())
                        except:
                            self.Print(f" Failed to send error response to {addr[0]}:{addr[1]}", 40)
                            session.is_connected = False
                            break
                
                except ConnectionResetError:
                    self.Print(f" Client {addr[0]}:{addr[1]} reset connection", 20)
                    session.is_connected = False
                except BrokenPipeError:
                    self.Print(f" Client {addr[0]}:{addr[1]} closed connection", 20)
                    session.is_connected = False
                except Exception as e:
                    self.Print(f" Error in message loop for {addr[0]}:{addr[1]}: {e}", 40)
                    session.is_connected = False
        
        except Exception as e:
            self.Print(f" Critical error in handle_client for {addr[0]}:{addr[1]}: {e}", 40)
        
        finally:
            # Clean up
            try:
                if session:
                    with self.upload_sessions_lock:
                        stale = [uid for uid, s in self.upload_sessions.items()
                                 if s.username == session.username]
                    for upload_id in stale:
                        session._cleanup_upload(upload_id)
                    self.unregister_session(session)
                with self.clients_lock:
                    if addr in self.clients:
                        del self.clients[addr]
                        self.Print(f" Client session removed for {addr[0]}:{addr[1]}", 20)
                sock.close()
                self.Print(f" Connection closed for {addr[0]}:{addr[1]}", 20)
            except Exception as cleanup_err:
                self.Print(f" Error during cleanup for {addr[0]}:{addr[1]}: {cleanup_err}", 40)


# Entry point
if __name__ == "__main__":
    server = Server(
        host=SERVER_HOST,
        port=SERVER_PORT,
        logging_level=LOGGING_LEVEL,
    )
    
    server.start()
